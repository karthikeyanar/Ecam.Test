function tableStructure() {
    this.cols = [];
    this.rows = [];
}

function removeHTML(html) {
    var regex = /(<([^>]+)>)/ig,
        body = html,
        result = body.replace(regex, "");

    return $.trim(result); //.replace(/\s+$/g, "").replace(/(\r\n|\n|\r)/gm, "").replace(/\s+/g, "");
}

// The download function takes a CSV string, the filename and mimeType as parameters
// Scroll/look down at the bottom of this snippet to see how download is called
var download = function(content, fileName, mimeType) {
    var a = document.createElement('a');
    mimeType = mimeType || 'application/octet-stream';

    if (navigator.msSaveBlob) { // IE10
        navigator.msSaveBlob(new Blob([content], {
            type: mimeType
        }), fileName);
    } else if (URL && 'download' in a) { //html5 A[download]
        a.href = URL.createObjectURL(new Blob([content], {
            type: mimeType
        }));
        a.setAttribute('download', fileName);
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    } else {
        location.href = 'data:application/octet-stream,' + encodeURIComponent(content); // only this mime type is supported
    }
}

function exportTable() {
    var $GSAListingTable = $("#GSAListingTable");
    var cols = '';
    var struct = new tableStructure();
    $("thead > tr", $GSAListingTable).each(function() {
        var $tr = $(this);
        $("th", $tr).each(function() {
            var $th = $(this);
            var colName = removeHTML($th.html());
            if (colName != '') {
                struct.cols.push(colName);
            }
        });
    });
    $("tbody > tr", $GSAListingTable).each(function() {
        var $tr = $(this);
        var row = [];
        $("td", $tr).each(function(i) {
            var $td = $(this);
            var value = removeHTML($td.html());
            if (i < struct.cols.length) {
                row.push(value);
            }
        });
        struct.rows.push(row);
    });
    console.log(struct);
    var csvContent = convertCSVContent(struct);
    download(csvContent, 'dowload.csv', 'text/csv;encoding:utf-8');
}

function convertCSVContent(struct) {
    var content = '';
    var cols = '';
    var rows = '';
    for (var i = 0; i < struct.cols.length; i++) {
        cols += '"' + struct.cols[i] + '",';
    }
    if (cols != '') {
        cols = cols.substring(0, cols.length - 1);
    }
    cols = cols + '\n';

    for (var i = 0; i < struct.rows.length; i++) {
        var row = '';
        for (var j = 0; j < struct.rows[i].length; j++) {
            row += '"' + struct.rows[i][j] + '",';
        }
        if (row != '') {
            row = row.substring(0, row.length - 1);
        }
        rows += row + '\n';
    }

    content = cols + rows;
    console.log(content);
    return content;
}